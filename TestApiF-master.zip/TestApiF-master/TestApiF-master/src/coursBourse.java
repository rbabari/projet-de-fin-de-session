/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 1758934
 */
public class coursBourse {
    double cOuverture;
    double cFermeture;
    double cFermetureAjuste;
    double cMax;
    double cMin;
    String cNom;
    
    public coursBourse(/*double cOuverture, double cFermeture, double cFermetureAjuste, double cMax, double cMin*/){
//        this.cOuverture=cOuverture;
//        this.cFermeture=cFermeture;
//        this.cFermetureAjuste=cFermetureAjuste;
//        this.cMax=cMax;
//        this.cMin=cMin;
    }
   
}
