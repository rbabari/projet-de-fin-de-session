import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

/**
 *
 * @author oydsc
 */
class FenetrePortefeuille extends JFrame{
    JTabbedPane onglet= new JTabbedPane();
    JPanel tableauDifferences=new JPanel();
    JPanel tableauPossessions=new JPanel();
    JPanel tableauAchats=new JPanel();
    
    private JPanel liste=new JPanel(new GridLayout(23,1));
    private JScrollPane scrPane=new JScrollPane(liste);
    private JPanel panneau;
    private JLabel labelActifs;
    
    private JPanel colonnes=new JPanel(new GridLayout(1,4));
    private JPanel colonnes1=new JPanel(new GridLayout(1,4));
    private JPanel colonnes2=new JPanel(new GridLayout(1,4));
    
    private JPanel liste1=new JPanel(new GridLayout(23,1));
    private JScrollPane scrPane1 = new JScrollPane(liste1);
    private JPanel panneau1;
    
    private JPanel liste2=new JPanel(new GridLayout(23,1));
    private JScrollPane scrPane2 = new JScrollPane(liste2);
    private JPanel panneau2;
    
    private JLabel tresorerie;
    private JLabel tresorerie1;
    
    private JLabel nColonne;
    private JLabel nValeur;
    private JLabel nVenteAchat;
    private JLabel nQuantite;
    
    private JLabel nom;
    private JLabel valeur;
    private Double[] choixActions={/*0.0,*/1.0,5.0,10.0,15.0,20.0,30.0,50.0,75.0,100.0,150.0,200.0};
    private JComboBox boite;
    private JLabel total;
    private JButton confirmationVente=new JButton("Confirmez vos ventes");
    private JButton confirmationAchat=new JButton("Confirmez vos achats");
    
    private ArrayList listeVentes=new ArrayList<>();
    private ArrayList listeAchats=new ArrayList<>();
    private double montantTresorerie=100000;
    private ArrayList listeMontants=new ArrayList<>();
    private ArrayList listeMontants1=new ArrayList<>();
    
    
    public FenetrePortefeuille(ArrayList<coursBourse> listeDonneesBoursieres, ArrayList<actifsPossedes> listeActifsPossedes, actifsPossedes actifsPossedes){
        super("portefeuille");
        
        tresorerie=new JLabel("Votre trésorerie : "+montantTresorerie);
        tresorerie1=new JLabel("Votre trésorerie : "+montantTresorerie);
        
        changementsPortefeuille(listeDonneesBoursieres,listeActifsPossedes);
        constructionListePoss(listeDonneesBoursieres,listeActifsPossedes);
        constructionListeAchats(listeDonneesBoursieres,listeActifsPossedes, actifsPossedes);
        
        tableauDifferences.add(scrPane);
        tableauPossessions.add(scrPane1);
        tableauAchats.add(scrPane2);
        
        onglet.addTab("Écart entre deux séances",tableauDifferences);
        onglet.addTab("Actifs possédés", tableauPossessions);
        onglet.addTab("Actifs à vendre", tableauAchats);
        
        this.add(onglet);
        this.setSize(getPreferredSize());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    
    private void constructionListePoss(ArrayList<coursBourse> listeDonneesBoursieres,ArrayList<actifsPossedes> listeActifsPossedes){
        liste1.add(tresorerie);
        
        nColonne=new JLabel("Nom de l'entreprise");
        nValeur=new JLabel("Valeur d'un actif");
        nVenteAchat=new JLabel("Actifs à vendre");
        nQuantite=new JLabel("Bénéfices maximaux");
        colonnes.add(nColonne);
        colonnes.add(nValeur);
        colonnes.add(nVenteAchat);
        colonnes.add(nQuantite);
        liste1.add(colonnes);
        
        for(int i=0;i<listeActifsPossedes.size();i++)
        {
            panneau1=new JPanel(new GridLayout(1,4));
            nom=new JLabel(listeActifsPossedes.get(i).aNom);
            valeur=new JLabel(String.valueOf(listeActifsPossedes.get(i).aValeurUnitaire));
            boite=new JComboBox(choixActions);
            
            System.out.println("boite selectionnee "+boite.getSelectedItem());
           
            listeMontants.add(boite.getSelectedItem());
                    
            total=new JLabel(String.valueOf(listeActifsPossedes.get(i).aValeurTotale));
            panneau1.add(nom);
            panneau1.add(valeur);
            panneau1.add(boite);
            panneau1.add(total);
            liste1.add(panneau1);
        }
        
        confirmationVente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("vente");
                
                double benefices=0;
                for(int i=0;i<listeMontants.size();i++)
                {
                    if(((Double)listeMontants.get(i)*listeActifsPossedes.get(i).aValeurUnitaire)<=listeActifsPossedes.get(i).aValeurTotale)
                    {
                        System.out.println("listebourse "+listeActifsPossedes.get(i).aValeurUnitaire);
                        benefices=benefices+ ((Double)listeMontants.get(i)*listeActifsPossedes.get(i).aValeurUnitaire);
                        System.out.println("benefices "+benefices);
                        
                        listeActifsPossedes.get(i).aValeurTotale=listeActifsPossedes.get(i).aValeurTotale-(Double)listeMontants.get(i)*listeActifsPossedes.get(i).aValeurUnitaire;
                    }
                }
                montantTresorerie=montantTresorerie+benefices;
                System.out.println("montant trésorerie "+montantTresorerie);
                tresorerie.setText("Votre trésorerie : "+montantTresorerie);
            }
        });
        liste1.add(confirmationVente);
    }

    private void constructionListeAchats(ArrayList<coursBourse> listeDonneesBoursieres,ArrayList<actifsPossedes> listeActifsPossedes, actifsPossedes actifsPossedes) {
        liste2.add(tresorerie1);
        
        nColonne=new JLabel("Nom de l'entreprise");
        nValeur=new JLabel("Prix d'un actif");
        nVenteAchat=new JLabel("Actifs à acheter");
        nQuantite=new JLabel("Achat maximal");
        colonnes1.add(nColonne);
        colonnes1.add(nValeur);
        colonnes1.add(nVenteAchat);
        colonnes1.add(nQuantite);
        liste2.add(colonnes1);
        
        for(int i=0;i<listeDonneesBoursieres.size();i++)
        {
            panneau2=new JPanel(new GridLayout(1,4));
            nom=new JLabel(listeDonneesBoursieres.get(i).cNom);
            valeur=new JLabel(String.valueOf(listeDonneesBoursieres.get(i).cFermetureAjuste));
            boite=new JComboBox(choixActions);
            System.out.println("boite selectionnee "+boite.getSelectedItem());
            listeMontants1.add(boite.getSelectedItem());
            total=new JLabel(String.valueOf(listeDonneesBoursieres.get(i).cFermetureAjuste*200));
            panneau2.add(nom);
            panneau2.add(valeur);
            panneau2.add(boite);
            panneau2.add(total);
            
            liste2.add(panneau2);
        }
        
        confirmationAchat.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("achat");
                
                double passifs=0;
                for(int i=0;i<listeMontants1.size();i++)
                {
                    try{
                        if(((Double) listeMontants1.get(i)*listeDonneesBoursieres.get(i).cFermetureAjuste)<listeDonneesBoursieres.get(i).cFermetureAjuste)
                        {
                            System.out.println("listemontant "+listeMontants1.get(i));
                            System.out.println("listeboursière "+listeDonneesBoursieres.get(i).cFermetureAjuste);
                            passifs=passifs+ ((Double) listeMontants1.get(i)*listeDonneesBoursieres.get(i).cFermetureAjuste);
                            System.out.println("passifs"+passifs);
                            
                            for(int j=0;j<listeActifsPossedes.size();j++)
                            {
                                if(listeActifsPossedes.get(j).aNom.equals(listeDonneesBoursieres.get(i).cNom))
                                {
                                    listeActifsPossedes.get(j).aActifsPossedes=listeActifsPossedes.get(j).aActifsPossedes+(Double) listeMontants1.get(i);
                                    listeActifsPossedes.get(j).aValeurTotale=listeActifsPossedes.get(j).aValeurTotale+((Double) listeMontants1.get(i)*listeDonneesBoursieres.get(i).cFermetureAjuste);
                                    listeActifsPossedes.get(j).aValeurUnitaire=listeDonneesBoursieres.get(i).cFermetureAjuste;
                                }
                                if(j==listeActifsPossedes.size() && listeActifsPossedes.get(j).aNom!=listeDonneesBoursieres.get(i).cNom)
                                {
                                    actifsPossedes.aNom.equals(listeDonneesBoursieres.get(i).cNom);
                                    listeActifsPossedes.get(j).aActifsPossedes=listeActifsPossedes.get(j).aActifsPossedes+(Double) listeMontants1.get(i);
                                    actifsPossedes.aValeurUnitaire=listeDonneesBoursieres.get(i).cFermetureAjuste;
                                    actifsPossedes.aValeurTotale=listeDonneesBoursieres.get(i).cFermetureAjuste*(Double) listeMontants1.get(i);
                                    listeActifsPossedes.add(actifsPossedes);
                                }
                            }
                        }
                    }
                    catch(Exception e){
                        System.out.println("pas de chiffre");
                    }
                }
                montantTresorerie=montantTresorerie-passifs;
                System.out.println("montant trésorerie "+montantTresorerie);
                tresorerie.setText("Votre trésorerie : "+montantTresorerie);
            }
        });
        liste2.add(confirmationAchat);
    }
    
    private void changementsPortefeuille(ArrayList<coursBourse> listeDonneesBoursieres,ArrayList<actifsPossedes> listeActifsPossedes){
        liste.add(tresorerie1);
        
        nColonne=new JLabel("Nom de l'entreprise");
        nValeur=new JLabel("Nombre d'actifs");
        nVenteAchat=new JLabel("Valeur de tous les actifs");
        nQuantite=new JLabel("Valeur des actifs à cette séance");
        colonnes2.add(nColonne);
        colonnes2.add(nValeur);
        colonnes2.add(nVenteAchat);
        colonnes2.add(nQuantite);
        liste.add(colonnes2);
        
        for(int i=0;i<listeActifsPossedes.size();i++)
        {
            panneau=new JPanel(new GridLayout(1,4));
            nom=new JLabel(listeActifsPossedes.get(i).aNom);
            valeur=new JLabel(String.valueOf(listeActifsPossedes.get(i).aActifsPossedes));
            
            for(int j=0;j<listeDonneesBoursieres.size();j++)
            {
                if(listeDonneesBoursieres.get(j).cNom.equals(listeActifsPossedes.get(i).aNom))
                {
                    labelActifs=new JLabel(String.valueOf(listeDonneesBoursieres.get(j).cFermetureAjuste*listeActifsPossedes.get(i).aActifsPossedes));
                    total=new JLabel(String.valueOf(listeDonneesBoursieres.get(j).cFermetureAjuste));
                }
            }
            
            panneau.add(nom);
            panneau.add(valeur);
            panneau.add(labelActifs);
            panneau.add(total);
            
            liste.add(panneau);
        }
    }
}
