import java.io.*;
import java.util.ArrayList;

/**
 *
 * @author oydsc
 */
public class portefeuille {
    private actifsPossedes actifsPossedes;
    private ArrayList<actifsPossedes> listeActifsPossedes=new ArrayList<>();
    
    public void portefeuille(ArrayList listeDonneesBoursieres){
        portefeuilleSauvegarde();
        
        FenetrePortefeuille fenetre=new FenetrePortefeuille(listeDonneesBoursieres,listeActifsPossedes,actifsPossedes);
        
        
        sauvegardePortefeuille();
    }
    
    private void portefeuilleSauvegarde() {
        try{
            FileReader fichier=new FileReader("sauvegarde.txt");
            BufferedReader lecteur=new BufferedReader(fichier);
            String ligne;
            
            while((ligne=lecteur.readLine())!=null)
            {
                System.out.println(ligne);
            }
            lecteur.close();
        }
        catch(IOException e)
        {
            
        }
    }

    private void sauvegardePortefeuille() {
        try{
            FileWriter fichier=new FileWriter("sauvegarde.txt");
            PrintWriter ecrire=new PrintWriter(fichier);
            
            for(int i=0;i<listeActifsPossedes.size();i++)
            {
                ecrire.println(listeActifsPossedes.get(i).aNom+"/"+listeActifsPossedes.get(i).aActifsPossedes+"/"+listeActifsPossedes.get(i).aValeurUnitaire+"/"+listeActifsPossedes.get(i).aValeurTotale);
            }
            ecrire.close();
        }
        catch(IOException e)
        {
            
        }
    }

    private void interfacePortefeuille() {
        
    }
}
