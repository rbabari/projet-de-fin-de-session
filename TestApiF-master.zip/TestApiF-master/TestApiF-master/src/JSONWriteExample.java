 // https://github.com/Corefinder89/SampleJavaCodes/blob/master/src/Dummy1.java

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

class Dummy1 {
    Date aujourdhui;
    Calendar calendrier=new GregorianCalendar();
    int an;
    int mois;
    int jour;
    int jourSemaine;
    
    int donneRegulee=0;
    
    public ArrayList nom=new ArrayList<>();
    public ArrayList<coursBourse> listeDonneesBoursieres=new ArrayList<>();
    
    coursBourse action;

    public static void main(String[] args) {
        new Dummy1().format();
    }
    
    Dummy1()
    {
        aujourdhui=new Date();
    }
    
    public void format()
    {
        calendrier.setTime(aujourdhui);

        an=calendrier.get(Calendar.YEAR);
        mois=calendrier.get(Calendar.MONTH)+1;
        jour=calendrier.get(Calendar.DAY_OF_MONTH);
        jourSemaine=calendrier.get(Calendar.DAY_OF_WEEK);
        
        nom.add("ADBE");
        nom.add("GOOG");
//        nom.add("AMZN");
//        nom.add("AAL");
//        nom.add("AAPL");
//        nom.add("T");
//        nom.add("BAC");
//        nom.add("BA");
//        nom.add("AIR.PAR");
//        nom.add("ADS.FRK");
//        nom.add("BAYN.FRK");
//        nom.add("BMW.FRK");
//        nom.add("DB");
//        nom.add("SAP.FRK");
//        nom.add("SI");
//        nom.add("AI.PAR");
//        nom.add("BNP.PAR");
//        nom.add("CA.PAR");
//        nom.add("ML.PAR");
//        nom.add("UG.PAR");
//        nom.add("RNO.PAR");
//        nom.add("KO");
//        nom.add("ORCL");
        
        for(donneRegulee=0;donneRegulee<=nom.size();donneRegulee++)
        {
            action=new coursBourse();
            chercherDonnes();
        }
           
        portefeuille portefeuille=new portefeuille();
        portefeuille.portefeuille(listeDonneesBoursieres);
    }
    
    public void chercherDonnes(){
        try {
            String inline = "";
            JSONParser parse;
            JSONObject jobj;
            JSONArray jsonarr_1;
            JSONObject jsonobj_1;
            JSONArray jsonarr_2;
            JSONObject jsonobj_2;
            JSONArray jsonarr_3;
            
            //int jourAnnuel=0;
        
            URL url = new URL("https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol="+nom.get(donneRegulee)+"&apikey=7AW139O6OCROPW7W");
            //Parse URL into HttpURLConnection in order to open the connection in order to get the JSON data
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            //Set the request to GET or POST as per the requirements
            conn.setRequestMethod("GET");
            //Use the connect method to create the connection bridge
            conn.connect();
            //Get the response status of the Rest API
            int responsecode = conn.getResponseCode();
            System.out.println("Response code is: " + responsecode);

            //Iterating condition to if response code is not 200 then throw a runtime exception
            //else continue the actual process of getting the JSON data
            if (responsecode != 200) {
                throw new RuntimeException("HttpResponseCode: " + responsecode);
            } else {
                //Scanner functionality will read the JSON data from the stream
                Scanner sc = new Scanner(url.openStream());
                while (sc.hasNext()) {
                    inline += sc.nextLine() + "\n";
                }
                System.out.println("\nJSON Response in String format");
                //System.out.println(inline);
                //Close the stream when reading the data has been finished
                sc.close();
            }

            //JSONParser reads the data from string object and break each data into key value pairs
            parse = new JSONParser();
            //Type caste the parsed json data in json object
            jobj = (JSONObject) parse.parse(inline);
            System.out.println("jobj#"+jobj);
            //Store the JSON object in JSON array as objects (For level 1 array element i.e Results)
            jsonarr_1 = new JSONArray();
            jsonarr_1.add(jobj.get("Meta Data"));
            //Get data for Results array
            for (int i = 0; i < jsonarr_1.size(); i++) {
                //Store the JSON objects in an array
                //Get the index of the JSON object and print the values as per the index
                jsonobj_1 = (JSONObject) jsonarr_1.get(i);
                System.out.println("jsonobj#"+jsonobj_1);
                //Store the JSON object in JSON array as objects (For level 2 array element i.e Address Components)
                System.out.println("Elements under results array");
                System.out.println("\n1. Information: " + jsonobj_1.get("1. Information"));
                System.out.println("2. Symbol: " + jsonobj_1.get("2. Symbol"));
                
                action.cNom=(String) jsonobj_1.get("2. Symbol");
                System.out.println("2. Symbole "+action.cNom);
                
                System.out.println("3. Last Refreshed: " + jsonobj_1.get("3. Last Refreshed"));
                System.out.println("4. Output Size: " + jsonobj_1.get("4. Output Size"));
                System.out.println("5. Time Zone: " + jsonobj_1.get("5. Time Zone"));
                //Get data for the Address Components array
                System.out.println("Elements under address_components array");
                System.out.println("The long names, short names and types are:");

                jsonarr_2 = new JSONArray();
                jsonarr_2.add(jobj.get("Time Series (Daily)"));
                System.out.println("jsonarr2 d "+jsonarr_2);
                System.out.println("jsonarr2size d "+jsonarr_2.size());
                
//                ArrayList listeDates=new ArrayList<>();
//                
//                for(int m=3;m>0;m--){
//                    
//                    if(mois<10 && jour<10)
//                    {
//                        listeDates.add(String.valueOf(an)+"-0"+String.valueOf(mois)+"-0"+String.valueOf(jour));
//
//                    }
//                    else if (mois<10 && jour>10)
//                    {
//                        listeDates.add(String.valueOf(an)+"-0"+String.valueOf(mois)+"-"+String.valueOf(jour));
//                    }
//                    else if(mois>10 && jour<10)
//                    {
//                        listeDates.add(String.valueOf(an)+"-"+String.valueOf(mois)+"-0"+String.valueOf(jour));
//                    }
//                    else
//                    {
//                        listeDates.add(String.valueOf(an)+"-"+String.valueOf(mois)+"-"+String.valueOf(jour));
//                    }
//
//                    jour=jour-1;
//                    
//                    if(jour<1 && (mois-1==1 || mois-1==3 || mois-1==5 || mois-1==7 || mois-1==8 || mois-1==10 || mois-1==12))
//                    {
//                        jour=31;
//                        mois=mois-1;
//                    }
//                    else if(jour<1 && (mois-1==4 || mois-1==6 || mois-1==9 || mois-1==11))
//                    {
//                        jour=30;
//                        mois=mois-1;
//                    }
//                    else if(jour<1 && mois-1==2 && ((an%4==0 && an%100!=0) || an%400==0))
//                    {
//                        jour=29;
//                        mois=mois-1;
//                    }
//                    else if(jour<1 && mois-1==2)
//                    {
//                        jour=28;
//                        mois=mois-1;
//                    }
//                    else if(mois-1<1)
//                    {
//                        an=an-1;
//                        mois=12;
//                        jour=31;
//                    }
//                    
//                }System.out.println("listeDates.size()); "+listeDates.size());
//                
                for (int j = 0; j < jsonarr_2.size(); j++) {
//
                    jsonobj_2 = (JSONObject) jsonarr_2.get(j);
                    jsonarr_3 = new JSONArray();
//                    
//                    for(int l=0;l<listeDates.size();l++)
                    {
                        jsonarr_3.add(jsonobj_2.get("2020-04-02"));
                        System.out.println(String.valueOf(an)+"-0"+String.valueOf(mois)+"-0"+String.valueOf(jour));
                        methodeProvisoire(jsonarr_3, jsonobj_2, j);
                        jsonarr_3.clear();
                    }
                }
            }
                //Disconnect the HttpURLConnection stream
                conn.disconnect();
            }
        catch(java.lang.NullPointerException e)
        {
            run();
        }
        catch (Exception e) {
            System.out.println("erreur");//e.printStackTrace();
        }
    }
    
    public void run() {
        try
        {
            System.out.println("début");
            Thread.sleep(60000);
            System.out.println("fin");
            if(donneRegulee<nom.size())
            {
                donneRegulee=donneRegulee-1;
            }
            
        }
        catch(InterruptedException e)
        {
            e.printStackTrace();
            System.exit(0);
        }
        }
    
    public void methodeProvisoire(JSONArray jsonarr_3, JSONObject jsonobj_2, int j){
        for (int k = 0; k < jsonarr_3.size(); k++) {
            //Same just store the JSON objects in an array
            //Get the index of the JSON objects and print the values as per the index
            JSONObject jsonobj_3 = (JSONObject) jsonarr_3.get(j);
            //Store the data as String objects
            String str_data1 = (String) jsonobj_3.get("1. open");
                action.cOuverture=Double.parseDouble(str_data1);
                System.out.println("1. open "+action.cOuverture);
            String str_data2 = (String) jsonobj_3.get("2. high");
                action.cMax=Double.parseDouble(str_data2);
                System.out.println("2. high "+action.cMax);
            String str_data3= (String) jsonobj_3.get("3. low");
                action.cMin=Double.parseDouble(str_data3);
                System.out.println("3. low "+action.cMin);
            String str_data4 = (String) jsonobj_3.get("4. close");
                action.cFermeture=Double.parseDouble(str_data4);
                System.out.println("4. close "+action.cFermeture);
            String str_data5 = (String) jsonobj_3.get("5. adjusted close");
                action.cFermetureAjuste=Double.parseDouble(str_data5);
                System.out.println("5. adjusted close "+action.cFermetureAjuste);
        }

        System.out.println("\n");
        listeDonneesBoursieres.add(action);
        
        }
}
